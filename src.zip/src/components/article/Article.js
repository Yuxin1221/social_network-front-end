import React from 'react'
import Articlebody from './Articlebody'
import PostArticle from './PostArticle'
export default function article() {
    return (
        <div>
            <PostArticle/>
             <br/><br/>
            <Articlebody/>
        </div>

    )
}
